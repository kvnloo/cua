import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root = process.cwd();
const queue = path.dirname(root);
const frozen = '9727e8cee4ec17c787b22457a72de36101a3b7be';
const raw = path.join(queue, 'native-tmp/cua-driver-uniffi-Lm7z0d');
const sourcePath = 'libs/cua-driver/scripts/generate-uniffi-bindings.mjs';
const source = fs.readFileSync(sourcePath, 'utf8');
const digest = x => crypto.createHash('sha256').update(x).digest('hex');
const normalizers = source.slice(source.indexOf('function normalizeWhitespace('), source.indexOf('const temporaryRoot ='));
// Execute only checked-in normalization/comparison functions, never the generator's build/generation entry point.
const context = vm.createContext({...fs, ...path, check: true});
vm.runInContext(normalizers, context, {filename: sourcePath + ':normalizers-only'});
const read = p => fs.readFileSync(path.join(raw,p),'utf8');
const py = {'src/cua_driver/_native.py': context.normalizePython(read('python/cua_driver_sdk.py')), 'src/cua_driver/_native_contract.py': context.normalizePythonCursorEffects(context.normalizePython(read('python/cua_driver_contract.py')))};
const ts = {};
for (const name of fs.readdirSync(path.join(raw,'typescript')).filter(n=>n.endsWith('.ts'))) ts[`src/native/${name}`] = context.normalizeTypeScript(name,read('typescript/'+name));
const result={observedUtc:new Date().toISOString(),sourceTree:frozen,generatorSha256:digest(source),method:'Independent replay of unchanged canonical normalizers and check function over retained raw output; no build or regeneration',files:[],negativeControls:[]};
for (const [language,files] of [['python',py],['typescript',ts]]) {
  const relroot = `libs/cua-driver/${language}`;
  context.applyGroup(path.join(root,relroot),'.cua-driver-uniffi-generated-files',files);
  const planned={...files,'.cua-driver-uniffi-generated-files':context.inventoryContents(Object.keys(files))};
  for (const [name,text] of Object.entries(planned)) {
    const rel=`${relroot}/${name}`;
    const disk=fs.readFileSync(rel);
    const tree=execFileSync('git',['show',`${frozen}:${rel}`]);
    if (!disk.equals(Buffer.from(text)) || !disk.equals(tree)) throw Error('Mismatch: '+rel);
    result.files.push({path:rel,bytes:disk.length,sha256:digest(disk),normalizedRawEqualsWorkingFile:true,workingFileEqualsFrozenGitBlob:true});
  }
  const first=Object.keys(files)[0];
  let refused=false;
  try { context.applyGroup(path.join(root,relroot),'.cua-driver-uniffi-generated-files',{...files,[first]:files[first]+'AUDIT_MUTATION\n'}); } catch(e) { if (!String(e).includes('stale UniFFI generated files')) throw e; refused=true; }
  if (!refused) throw Error('Mutation was not detected');
  result.negativeControls.push({language,changedExpectedBytesRejected:true,noFilesMutated:true});
}
result.frozenTrackedWorktreeMatch=execFileSync('git',['diff','--name-only',frozen,'--']).toString().trim()==='';
if (!result.frozenTrackedWorktreeMatch) throw Error('Frozen worktree changed');
fs.writeFileSync(path.join(queue,'audit-canonical-20261010/retained-binding-comparison.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:'PASS',files:result.files.length,negativeControls:result.negativeControls.length,frozenTrackedWorktreeMatch:result.frozenTrackedWorktreeMatch,generatorSha256:result.generatorSha256},null,2));
