import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
process.on('exit', () => {
  const lines=fs.readFileSync('PROCESS_MAPS','utf8').split('\n').filter(s=>s.includes('libcua_driver_sdk.so')||s.includes('cua_driver_node_runtime.node'));
  const paths=[...new Set(lines.map(s=>s.trim().split(/\s+/).at(-1)))].sort();
  const artifacts=paths.map(p=>({path:p,realpath:fs.realpathSync(p),sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')}));
  const receipt={pid:process.pid,requireNative:process.env.CUA_DRIVER_REQUIRE_UNIFFI,artifacts};
  fs.writeFileSync(path.join(process.env.CUA_AUDIT_OUTPUT,`node-loaded-native-${process.pid}.json`),JSON.stringify(receipt,null,2)+'\n');
});
