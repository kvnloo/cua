import sys, os, json, hashlib, unittest
from pathlib import Path
out=Path(os.environ['CUA_AUDIT_OUTPUT'])
assert os.environ.get('CUA_DRIVER_REQUIRE_UNIFFI')=='1'
suite=unittest.defaultTestLoader.discover('tests', pattern='test_cursor_motion.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
loaded=sys.modules.get('cua_driver._native')
lib=Path(loaded._UniffiLib._name).resolve() if loaded else None
maps=sorted(set(line.split()[-1] for line in Path('PROCESS_MAPS').read_text().splitlines() if 'libcua_driver_sdk.so' in line))
receipt={'requireNative':os.environ['CUA_DRIVER_REQUIRE_UNIFFI'],'testsRun':result.testsRun,'skipped':len(result.skipped),'failures':len(result.failures),'errors':len(result.errors),'nativeModulePath':getattr(loaded,'__file__',None),'ctypesLoadedPath':str(lib) if lib else None,'mappedSdkPaths':maps,'loadedSdkSha256':hashlib.sha256(lib.read_bytes()).hexdigest() if lib else None}
(out/'python-loaded-native-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==5 and not result.skipped, receipt
assert lib and str(lib) in maps,receipt
assert receipt['loadedSdkSha256']=='2e9ba113619db12f66397fbf020befccb1588c1943f2c36632bf37fa710e0371',receipt
