from pathlib import Path
import os, subprocess, hashlib, json, datetime, sys
queue=Path('QUALIFICATION_ROOT')
root=queue/'owner-current'; out=queue/'audit-canonical-20261010'
files=[queue/'target-native/release/libcua_driver_sdk.so',root/'libs/cua-driver/python/src/cua_driver/libcua_driver_sdk.so',root/'libs/cua-driver/typescript/node_modules/@trycua/cua-driver-linux-x64-gnu/libcua_driver_sdk.so',root/'libs/cua-driver/typescript/node_modules/@trycua/cua-driver-linux-x64-gnu/cua_driver_node_runtime.node',queue/'qualification-new-20261010/native-node-runtime-resolved-Cargo.lock',root/'libs/cua-driver/typescript/node_modules/uniffi-bindgen-react-native/Cargo.lock',root/'libs/cua-driver/python/tests/test_cursor_motion.py',root/'libs/cua-driver/typescript/test/cursor-motion.test.mjs']
files+=sorted((root/'libs/cua-driver/typescript/dist').rglob('*.js'))
files+=sorted((root/'libs/cua-driver/typescript/dist').rglob('*.d.ts'))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=root).decode().strip()
data={'observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozenTree':git('write-tree'),'trackedWorktreeDelta':git('diff','--name-only','9727e8cee4ec17c787b22457a72de36101a3b7be'),'files':{str(p.relative_to(queue)):{'sha256':h(p),'bytes':p.stat().st_size,'resolvedPath':str(p.resolve())} for p in files},'observationWrappers':{n:h(out/n) for n in ['replay-python-fixtures.py','capture-node-loaded.mjs']},'requireNative':os.environ.get('CUA_DRIVER_REQUIRE_UNIFFI'),'commands':{'python':'CUA_DRIVER_REQUIRE_UNIFFI=1 PYTHONPATH=src python3 <observation-wrapper executing unittest discover tests/test_cursor_motion.py>','node':'CUA_DRIVER_REQUIRE_UNIFFI=1 node --import <observation-only exit hook> --test test/cursor-motion.test.mjs'},'isolatedHome':os.environ.get('HOME')}
assert data['frozenTree']=='9727e8cee4ec17c787b22457a72de36101a3b7be' and not data['trackedWorktreeDelta']
for p in files[:3]:assert h(p)=='2e9ba113619db12f66397fbf020befccb1588c1943f2c36632bf37fa710e0371'
(out/f'native-replay-{sys.argv[1]}-snapshot.json').write_text(json.dumps(data,indent=2)+'\n')
print('PASS snapshot',sys.argv[1],len(data['files']),'artifacts')
