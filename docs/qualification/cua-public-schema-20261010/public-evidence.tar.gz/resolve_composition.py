from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'owner-current'
paths=['docs/content/docs/cua-driver/reference/mcp-tools/batch.mdx','libs/cua-driver/rust/Skills/cua-driver/SKILL.md','libs/cua-driver/rust/Skills/cua-driver/WORKFLOW.md','libs/cua-driver/rust/crates/cua-driver-core/src/protocol.rs']+[f'scripts/docs-generators/cli-specs/cua-driver-mcp-{p}.json' for p in ['linux','macos','windows']]
rx=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n',re.M|re.S)
for name in paths:
 p=root/name; s=p.read_text()
 def resolve(m):
  ours,theirs=m.groups()
  if name.endswith('/protocol.rs') or name.endswith('/SKILL.md'):
   return theirs.replace('observe:true', 'observe:{{}}' if name.endswith('/protocol.rs') else 'observe:{}')
  return ours.replace('run_actions','run_steps')
 s,n=rx.subn(resolve,s)
 assert n>0,name
 assert not any(mark in s for mark in ['<<<<<<<','>>>>>>>']), name
 p.write_text(s)
# #4888's current roster follows #4935, including its invoke-only alias.
p=root/'libs/cua-driver/rust/crates/cua-driver/tests/protocol_schema_test.rs'
s=p.read_text(); assert 'names.contains("run_actions")' in s
s=s.replace('names.contains("run_actions")','names.contains("run_steps")',1)
s=s.replace('"runtime-only batch tool missing"\n    );','"runtime-only batch tool missing"\n    );\n    assert!(\n        !names.contains("run_actions"),\n        "legacy run_actions alias must stay hidden"\n    );',1)
p.write_text(s)
