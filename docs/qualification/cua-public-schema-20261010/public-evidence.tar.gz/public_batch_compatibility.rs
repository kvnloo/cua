//! NEW qualification suite for the owner/current-main composition.
//! Exercises the real core registry and QuickJS with a fake action handler.
//! This does not certify a platform Driver, transport, native SDK ABI, or GUI.

use cua_driver_core::authorization::PermissionMode;
use cua_driver_core::protocol::ToolResult;
use cua_driver_core::session_authorization::{
    EffectiveAuthorizationContext, SessionAuthorizationRegistry, SessionModeCeiling,
};
use cua_driver_core::tool::{Tool, ToolDef, ToolRegistry};
use serde_json::{json, Value};
use std::io::Write;
use std::sync::{Arc, Mutex};
use std::time::Duration;

struct FakeClick {
    def: ToolDef,
    calls: Arc<Mutex<Vec<Value>>>,
}

#[async_trait::async_trait]
impl Tool for FakeClick {
    fn def(&self) -> &ToolDef {
        &self.def
    }
    async fn invoke(&self, args: Value) -> ToolResult {
        self.calls.lock().unwrap().push(args);
        ToolResult::text("fake click accepted")
    }
}

fn registry() -> (Arc<ToolRegistry>, Arc<Mutex<Vec<Value>>>) {
    let calls = Arc::new(Mutex::new(Vec::new()));
    let mut r = ToolRegistry::new();
    r.register(Box::new(FakeClick {
        def: ToolDef {
            name: "click".into(),
            description: "qualification fake".into(),
            input_schema: json!({"type":"object","properties":{
                "pid":{"type":"integer"}, "window_id":{"type":"integer"}
            }}),
            read_only: false,
            destructive: false,
            idempotent: false,
            open_world: false,
        },
        calls: calls.clone(),
    }));
    r.register_session_tools();
    let r = Arc::new(r);
    r.init_self_weak();
    (r, calls)
}

fn context(allow: Option<&str>) -> Arc<EffectiveAuthorizationContext> {
    let mode = if allow.is_some() {
        PermissionMode::Bounded
    } else {
        PermissionMode::Unrestricted
    };
    let ceiling = SessionModeCeiling::for_trusted_sessions(
        [mode],
        mode == PermissionMode::Unrestricted,
        Duration::from_secs(60),
        Duration::from_secs(30),
    )
    .unwrap();
    let manifest = allow.map(|tools| {
        let source = format!("version: 2\nmode: bounded\nexpires_after: 1h\nidle_timeout: 30m\nallow:\n  tools: [{tools}]\n");
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(source.as_bytes()).unwrap();
        Arc::new(cua_driver_core::session_manifest::load_manifest(file.path()).unwrap())
    });
    SessionAuthorizationRegistry::with_ceiling(ceiling)
        .compatibility_context(mode, manifest)
        .unwrap()
}

fn batch() -> Value {
    json!({"steps":[{"tool":"click","args":{"pid":42,"window_id":7}}]})
}
fn structure(r: &ToolResult) -> &Value {
    r.structured_content.as_ref().expect("structured result")
}

#[tokio::test]
async fn alias_is_hidden_but_reachable_with_safe_invalid_arguments() {
    let (r, calls) = registry();
    let names: Vec<_> = r.tool_names().collect();
    assert!(names.contains(&"run_steps"));
    assert!(!names.contains(&"run_actions"));
    for name in ["run_steps", "run_actions"] {
        let result = r
            .invoke_with_context(name, json!(false), context(None))
            .await;
        assert_eq!(result.is_error, Some(true));
        assert_eq!(structure(&result)["code"], "invalid_arguments");
        assert_eq!(structure(&result)["tool"], "run_steps");
    }
    assert!(calls.lock().unwrap().is_empty());
}

#[tokio::test]
async fn alias_reaches_the_same_fake_action_and_reports_deprecation() {
    let (r, calls) = registry();
    for name in ["run_steps", "run_actions"] {
        let result = r.invoke_with_context(name, batch(), context(None)).await;
        assert_ne!(result.is_error, Some(true));
        assert_eq!(structure(&result)["ok"], true);
        assert_eq!(structure(&result)["executed"], 1);
        let text = serde_json::to_string(&result.content).unwrap();
        assert_eq!(text.contains("is deprecated"), name == "run_actions");
    }
    assert_eq!(calls.lock().unwrap().len(), 2);
}

#[tokio::test]
async fn both_names_meet_the_same_outer_manifest_denial() {
    let (r, calls) = registry();
    let current = r
        .invoke_with_context("run_steps", batch(), context(Some("click")))
        .await;
    let legacy = r
        .invoke_with_context("run_actions", batch(), context(Some("click")))
        .await;
    for result in [&current, &legacy] {
        assert_eq!(result.is_error, Some(true));
        assert_eq!(structure(result)["refusal"]["code"], "permission_denied");
    }
    assert_eq!(structure(&current), structure(&legacy));
    assert!(calls.lock().unwrap().is_empty());
}

#[tokio::test]
async fn legacy_manifest_batch_name_preserves_inner_denial_parity() {
    let (r, calls) = registry();
    let current = r
        .invoke_with_context("run_steps", batch(), context(Some("run_actions, click")))
        .await;
    let legacy = r
        .invoke_with_context("run_actions", batch(), context(Some("run_actions, click")))
        .await;
    for result in [&current, &legacy] {
        assert_eq!(result.is_error, Some(true));
        assert_eq!(structure(result)["failed_step"], 0);
        assert_eq!(structure(result)["executed"], 1);
        assert!(serde_json::to_string(structure(result))
            .unwrap()
            .contains("capability manifest"));
    }
    assert_eq!(structure(&current), structure(&legacy));
    let direct = r
        .invoke_with_context(
            "click",
            json!({"pid":42,"window_id":7}),
            context(Some("run_actions, click")),
        )
        .await;
    assert_eq!(
        structure(&direct)["refusal"]["code"],
        "bounded_resource_outside_manifest"
    );
    assert!(calls.lock().unwrap().is_empty());
}

#[cfg(feature = "script")]
#[tokio::test]
async fn script_calls_meet_the_same_ordinary_inner_manifest_denial() {
    let (r, calls) = registry();
    let direct = r
        .invoke_with_context(
            "click",
            json!({"pid":42,"window_id":7}),
            context(Some("run_script, click")),
        )
        .await;
    assert_eq!(
        structure(&direct)["refusal"]["code"],
        "bounded_resource_outside_manifest"
    );
    let script = r
        .invoke_with_context(
            "run_script",
            json!({"script":"await cua.call('click', {pid:42,window_id:7}); return 1;"}),
            context(Some("run_script, click")),
        )
        .await;
    assert_eq!(script.is_error, Some(true));
    assert_eq!(structure(&script)["error"]["code"], "tool_error");
    assert!(structure(&script)["error"]["message"]
        .as_str()
        .unwrap()
        .contains("capability manifest"));
    assert!(calls.lock().unwrap().is_empty());
}

#[cfg(feature = "script")]
#[test]
fn operator_opt_out_registry_roster() {
    if let Ok(expected) = std::env::var("PUBLIC_CUA_QUALIFICATION_SCRIPT_EXPECTED") {
        let (r, _) = registry();
        assert_eq!(r.get_def("run_script").is_some(), expected == "on");
        assert!(r.get_def("run_steps").is_some());
        assert!(r.get_def("run_actions").is_none());
        return;
    }
    for (label, disable, legacy, config, expected) in [
        ("default", None, None, None, "on"),
        ("disable_env", Some("1"), None, None, "off"),
        ("legacy_env", None, Some("0"), None, "off"),
        (
            "disable_config",
            None,
            None,
            Some(r#"{"disable_run_script":true}"#),
            "off",
        ),
        (
            "legacy_config",
            None,
            None,
            Some(r#"{"experimental_script":false}"#),
            "off",
        ),
        (
            "opt_out_wins",
            Some("1"),
            Some("1"),
            Some(r#"{"experimental_script":true}"#),
            "off",
        ),
    ] {
        let home = tempfile::tempdir().unwrap();
        if let Some(source) = config {
            let d = home.path().join(".cua-driver");
            std::fs::create_dir(&d).unwrap();
            std::fs::write(d.join("config.json"), source).unwrap();
        }
        let mut child = std::process::Command::new(std::env::current_exe().unwrap());
        child
            .args(["--exact", "operator_opt_out_registry_roster", "--nocapture"])
            .env("HOME", home.path())
            .env("USERPROFILE", home.path())
            .env_remove("CUA_DRIVER_DISABLE_RUN_SCRIPT")
            .env_remove("CUA_DRIVER_EXPERIMENTAL_SCRIPT")
            .env("PUBLIC_CUA_QUALIFICATION_SCRIPT_EXPECTED", expected);
        if let Some(value) = disable {
            child.env("CUA_DRIVER_DISABLE_RUN_SCRIPT", value);
        }
        if let Some(value) = legacy {
            child.env("CUA_DRIVER_EXPERIMENTAL_SCRIPT", value);
        }
        let output = child.output().unwrap();
        assert!(
            output.status.success(),
            "{label}: {}",
            String::from_utf8_lossy(&output.stdout)
        );
    }
}

#[cfg(feature = "yaml")]
#[test]
fn both_names_meet_the_same_configured_policy_denial() {
    if std::env::var("PUBLIC_CUA_QUALIFICATION_POLICY_CHILD").as_deref() == Ok("1") {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async {
            let (r, calls) = registry();
            let current = r
                .invoke_with_context("run_steps", batch(), context(None))
                .await;
            let legacy = r
                .invoke_with_context("run_actions", batch(), context(None))
                .await;
            for result in [&current, &legacy] {
                assert_eq!(result.is_error, Some(true));
                assert_eq!(structure(result)["refusal"]["code"], "permission_denied");
            }
            assert_eq!(structure(&current), structure(&legacy));
            assert!(calls.lock().unwrap().is_empty());
        });
        return;
    }
    let home = tempfile::tempdir().unwrap();
    let policy = home.path().join("ordinary-policy.yaml");
    std::fs::write(
        &policy,
        "allow:\n  tools: [click, run_steps]\ndeny:\n  tools: [run_steps]\n",
    )
    .unwrap();
    let output = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "--exact",
            "both_names_meet_the_same_configured_policy_denial",
            "--nocapture",
        ])
        .env("HOME", home.path())
        .env("USERPROFILE", home.path())
        .env("CUA_DRIVER_POLICY_FILE", policy)
        .env("PUBLIC_CUA_QUALIFICATION_POLICY_CHILD", "1")
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}
