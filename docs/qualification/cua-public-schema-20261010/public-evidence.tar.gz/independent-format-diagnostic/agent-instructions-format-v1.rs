// Exact format! invocation extracted from public frozen tree 8c49e37db4e3ae1c27ebf2814659ad179dc34206
fn main() {
    let tree_kind = "AX";
    let script_line = "";
    let platform_skill_pointer = "skill://cua-driver/LINUX.md";
    let instructions =
    format!(
        r#"cua-driver: background GUI automation. No shell: for non-GUI outcomes use an app API/SDK, CLI or filesystem and read the result back there.

Efficient loop:
1. `list_windows({{app:"Name"}})` or `launch_app` for `pid` and `window_id`. Unfiltered `list_windows`/`list_apps` list the whole host.
2. Read narrowly: `get_window_state` with `query:"Save"` (or `max_elements`). Re-read with `since:"latest"` for only what changed. For just a picture, `include_accessibility_tree:false` (tokens stay valid).
3. Act by `element_token` ({tree_kind}): row `[N]` is `<snapshot_id>:N`. Pixel `x,y` only for surfaces missing from the tree.
4. Act through `run_steps({{steps:[{{tool,args}}],observe:{}}})`, even for one step: it stops at the first failure and returns what changed, so no separate re-read.{script_line}
5. Verify at checkpoints, not after every action: `verify_state(pid, window_id, expect)`. `unknown` and `effect:"unverifiable"` are not success.

Use the narrowest semantic route first: `set_window_frame` plus `list_windows` for geometry, typed browser tools for pages, clipboard tools for the clipboard. Stay in the background; `delivery_mode:"foreground"` only if refused or unverifiable.

`start_session` is optional; repeat a short `session` label on every call that accepts it. On continuation/recent-work, call `history_status`; if ready, make one bounded initial `history_query` before broad discovery.

Details: `skill://cua-driver/SKILL.md` and {platform_skill_pointer}."#
    );
    assert!(instructions.contains("run_steps"));
}
