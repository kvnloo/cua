# NEW Cua public qualification checkpoint

This checkpoint reconstructs a local owner/current-main composition from public source pins. It is not a new schema implementation, a landing request, or a certification of the owner PR. All tests here are NEW after workspace reset.

## Restore exact public source

1. Clone https://github.com/trycua/cua.git into an isolated directory.
2. Fetch the public owner PR head and detach at e7d056e8def8d5e0027025ee7b9511280bf8f8c5.
3. Apply owner-to-composition-v3.patch with git apply --index. This includes current-main public changes, mechanical merge resolutions, the minimal owner roster correction, and the NEW ordinary compatibility test.
4. git write-tree must equal 9727e8cee4ec17c787b22457a72de36101a3b7be. Confirm public_batch_compatibility.rs SHA256 is a513ccd3fb60854f21a9e220e28bc5867cccfc299b11ac72e544dd62d6a2baf1.

The public current-main pin is 815dfd96a10c83cb50c9151250a227d3d0ea4fc5. No fork120 schema source is merged. Preserve original owner history and credit when adapting any part of this work.

## Reproduction scope

Run the Cargo commands from libs/cua-driver/rust. Use Rust 1.97.1, a fresh isolated Cargo target, CARGO_BUILD_JOBS=1, and an isolated HOME. Keep host input/VM/Fleet tests off.

- cargo test --locked -p cua-driver-contract
- cargo test --locked -p cua-driver-core --test public_batch_compatibility -- --test-threads=1

The V2 test-development run is preserved as 5 passed / 2 incorrect-oracle failures. The independently corrected V3 suite was frozen for BOTH unchanged merged main and the composed owner before either contrast. Both source-fresh arms passed 7/7 with zero skips. Independent same-build replay of each arm also passed 7/7 in a clean HOME and empty inherited environment; these are replays, not independent rebuilds. The NEW compatibility suite uses the real Rust core/QuickJS with a fake action handler. It cannot establish platform Driver/MCP, generated-SDK ABI, GUI delivery, cross-platform, or provider acceptance.

See composition-decisions.md and the frozen-scope records for exact provenance, prior failed v1 format escape, and pending gates. The checkpoint retains V1/V2/V3 owner-relative patches, the failed V2 suite and both resolver versions. frozen-scope-v2.json maps its suite hash to public_batch_compatibility-v2.rs; frozen-differential-v3.json describes the current suite. frozen-scope.json describes original v1 paths; its resolve_composition.py checksum maps to resolve_composition-v1.py here. The original local env.sh is retained as hashed environment provenance; adapt its local path when reproducing in a new directory. Native SDK tests only count after canonical native SDK build/staging with CUA_DRIVER_REQUIRE_UNIFFI=1 and zero skips. Snapshot/binding generation remains a separate canonical native build gate.

No publication, merge, or release authorization is implied by this checkpoint.

For the main contrast, detach a separate public clone/worktree at 815dfd96a10c83cb50c9151250a227d3d0ea4fc5, apply main-suite-only-v3.patch, and confirm git write-tree equals a3f5282f67f0a3e705ceb67140590afdbc7a7227. Build into a separate fresh Cargo target; use the identical frozen suite.

## Completed differential and full-gate status

The composed full core --lib gate remains FAIL: 942 passed / 13 failed / zero skips. All exact 13 failed names also fail individually on a source-fresh unchanged-main --lib binary, each 0 passed / 1 failed. That is a selected baseline observation, not a full main suite pass. Logs show Landlock-unavailable / EPERM context; this receipt does not establish a general environmental root cause. No containment or host security setting was changed. Native SDK compatibility and canonical binding/snapshot generation remain pending.

The archive excludes binaries, toolchains, caches, full checkout inventories and local homes. Every member is allowlisted and hashed by checkpoint-manifest.json. Public patches plus source pins reconstruct exact source trees; V1/V2 failures remain part of the record. See completed-gates.json for commands, scopes and binary identities.

## Evidence-only branch source

The proposed evidence branch dot/cua/owner-schema-composition-proof-20261010 is parented on owner e7d056e8def8d5e0027025ee7b9511280bf8f8c5 and adds only this receipt package. Its production source remains the untouched owner head; it is different from the tested V3 owner/current-main composition reconstructed by the archive. Fork PR120 is credited for test direction only and its competing schema ancestry is not merged.
