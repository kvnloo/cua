# NEW local owner/current-main qualification

This is a fresh public-source qualification after workspace reset. It does not recover or repeat prior results.

## Source and ownership

- Owner: injaneity, trycua/cua#4888, e7d056e8def8d5e0027025ee7b9511280bf8f8c5.
- Current public main: 815dfd96a10c83cb50c9151250a227d3d0ea4fc5.
- Owner/current-main merge base: 7b5e8b1ca45e39cf9ff9f246f74c849b307fc2cc.
- Rename merge: d2b14913df638f59d37c6b59b6d85764d48d7b23 (#4935).
- Default-script merge: 815dfd96a10c83cb50c9151250a227d3d0ea4fc5 (#4936).
- Fork-only test carrier: kvnloo/cua#120, 3d9ab56ba0893e2a238056483bdf56c91c2cdc72. Its competing #4871 schema ancestry is not merged here.

Owner history already retains injaneity's typed/schema work, Kevin Rajan's compatibility repair authorship, and original source credit. No original commits were replaced or rewritten. This work does not change or claim the owner PR.

Latest maintainer request: https://github.com/trycua/cua/pull/4888#issuecomment-6097660183 (f-trycua, 2026-10-10T12:48:30Z).

## Seven mechanical merge conflicts

1. batch.mdx: preserve owner's narrowed schema tables and object-form observe, rename the published tool to run_steps; retain current-main run_script section.
2. bundled SKILL.md: preserve current-main run_steps and script guidance, retaining owner's advertised object-form observe.
3. bundled WORKFLOW.md: preserve owner's object-form observe hunk under the published run_steps name, retain current-main script flow.
4. core protocol.rs: retain current-main script_line and run_steps name, with owner's advertised object-form observe and proper Rust format escaping.
5–7. Linux/macOS/Windows CLI snapshots: preserve owner schema changes and object-form observe description, rename the published batch tool, retain current-main run_script entry.

Snapshots/doc outputs are conflict-resolved and provisional. They have not been canonically regenerated or certified. The Linux native generator must validate Linux; macOS/Windows require their own native dump and remain unverified.

The existing owner live schema lint remains the lint framework. Its current-main roster now requires run_steps and refuses advertising run_actions. The delivery-mode roster uses run_steps.

## Fresh compiler preflight correction

V1 tree 8c49e37db4e3ae1c27ebf2814659ad179dc34206 contained a mechanical Rust format-string escaping error. Independent source review caught it before core compilation. Exact v1 source tree, patches, freeze record, and resolver-v1.py remain retained. Contract tests on that candidate cannot certify core.

V2 tree 22aa8c0ac9f13cabc5fb0c94fa9d072dd7724b06 corrects only the literal empty-object format escape. The NEW suite is unchanged, SHA256 1853c702495610475a8083818a58909399868c23a18fc0a0e5a157295bba1827. Independent exact-source leaf compiler contrast is complete: V1 RED exit 1 (unescaped positional format argument), V2 GREEN exit 0, rustc 1.97.1, emit-metadata only. This is narrower than core qualification. Corrected production core compiled successfully. The NEW V2 supplemental suite finished 5 passed / 2 failed because its direct prerequisite expected generic permission_denied instead of established bounded_resource_outside_manifest. This is a test-development oracle failure, not a production repair. Exact failed V2 source, log and binary hash are retained.

## Results available now

- NEW locked contract gate: 66 unit + 4 visual integration tests passed, no failures or skips. Exit 0.
- Rust 1.97.1 minimal + rustfmt restored into isolated queue homes. Official rustup-init checksum verified.
- NEW V2 supplemental core suite: 5 passed / 2 failed, zero skips; two incorrect direct refusal-code expectations.
- NEW existing owner core --lib suite: 942 passed / 13 failed, zero skips. Thirteen perception-worker fixtures reported Landlock unavailable / EPERM before worker-specific outcomes. The full gate remains FAIL. All exact 13 failed names also fail individually on a source-fresh unchanged-main --lib binary, each 0 passed / 1 failed; this is a selected baseline observation, not a full main unit-suite pass or general causal proof. No containment bypass was attempted.
- NEW V3 identical differential suite: source-fresh unchanged main and composition each passed 7/7, zero skips. Independent same-build replay of each passed 7/7 in clean HOME/empty inherited environment; no independent rebuild claim.
- Native Python/TypeScript ABI matrix: not run.
- Canonical binding/snapshot drift: not run.
- Platform Driver/MCP, desktop delivery, cross-platform, provider acceptance, release or merge readiness: not certified.

The NEW suite exercises the real Rust core registry and QuickJS with a fake click handler. It tests ordinary hidden-alias, capability/policy parity and script opt-out behavior; it does not simulate a native platform Driver or native SDK ABI.

## V3 differential freeze

Independent source review confirms the direct bounded-resource refusal mapping is byte-identical on owner/main. Only two direct expected codes change to bounded_resource_outside_manifest; outer policy/manifest permission_denied and script tool_error/message checks stay intact. No production change.

- Composed owner/current-main + V3 suite tree: 9727e8cee4ec17c787b22457a72de36101a3b7be.
- Unchanged merged main 815dfd96 + identical test-only suite tree: a3f5282f67f0a3e705ceb67140590afdbc7a7227.
- V3 suite SHA256: a513ccd3fb60854f21a9e220e28bc5867cccfc299b11ac72e544dd62d6a2baf1.
- Failed V2 binary SHA256: a5cca9d6566d8dd9f0bd34c4a84cf939ea0b0d1d47e93ce275722f2a65b25d70. The binary itself is intentionally excluded from this compact public checkpoint.

V3 was frozen before either arm ran. Both arms finished 7/7 with source-fresh binaries and separate targets; independent same-build replays also finished 7/7. Composed binary SHA256 6aa1636c6b589304fd8a6b0661e2b3a5be42d105d086249be147cde84fb3790e; unchanged-main binary SHA256 4e2b78282dfd99ffe87d01407df8a85e41553613b3216856205cee8f4a8bb6b3. Main selected-baseline --lib binary SHA256 5bd12ac83fcd620cc00c68499a9f64fe6c6ebf7a40590cac9ad748c61ed77cbc.
